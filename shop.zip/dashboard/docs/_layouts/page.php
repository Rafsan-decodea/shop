---
layout: default
---

<div class="content-wrapper px-4 py-2">
  {% if page.title and page.title != blank %}
  <div class="content-header">
    <h1>{{ page.title }}</h1>
  </div>
  {% endif %}
  <div class="content px-2">
    {{ content }}
  </div>
</div>
