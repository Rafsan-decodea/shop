<!DOCTYPE html>
<html lang="{{ page.lang | default: site.lang | default: "en" }}">

  {%- include head.html -%}

  <body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed">
    <div class="wrapper">

      {%- include preloader.html -%}

      {%- include navbar.html -%}
      {%- include sidebar.html -%}

      {{ content }}

      {%- include footer.html -%}
    </div>

    {% include foot.html -%}
  </body>
</html>
